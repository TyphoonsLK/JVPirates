  def run_menu(self):
      #"""Handles menu logic and rendering."""
      self.display_surface.fill((30, 30, 30))  # Background color for the menu
      font = pygame.font.Font(None, 74)  # Default font, size 74

      # Render menu options
      for index, option in enumerate(self.menu_options):
          color = (255, 255, 255) if index == self.selected_option else (150, 150, 150)
          text = font.render(option, True, color)
          # Position each menu item
          self.display_surface.blit(text, (300, 200 + index * 100))

      # Event handling for menu navigation
      for event in pygame.event.get():
          if event.type == pygame.QUIT:
              pygame.quit()
              sys.exit()
          elif event.type == pygame.KEYDOWN:
              if event.key == pygame.K_DOWN:
                  self.selected_option = (self.selected_option + 1) % len(self.menu_options)
              elif event.key == pygame.K_UP:
                  self.selected_option = (self.selected_option - 1) % len(self.menu_options)
              elif event.key == pygame.K_RETURN:
                  if self.selected_option == 0:  # Play Now
                      self.in_menu = False
                  elif self.selected_option == 1:  # Settings
                      print("Settings selected!")  # Add your settings logic
                  elif self.selected_option == 2:  # Credits
                      print("Credits selected!")  # Add your c









def run_menu(self):
    """Handles menu logic and rendering."""
    # Background color with gradient-like effect
    self.display_surface.fill((30, 30, 30))
    for i in range(0, WINDOW_HEIGHT, 2):  # Add gradient stripes for aesthetics
        pygame.draw.rect(
            self.display_surface,
            (30 + i // 20, 30 + i // 20, 60),
            (0, i, WINDOW_WIDTH, 2)
        )

    # Title text
    title_font = pygame.font.Font(None, 100)
    title_text = title_font.render("GAME MENU", True, (255, 255, 255))
    self.display_surface.blit(
        title_text,
        (WINDOW_WIDTH // 2 - title_text.get_width() // 2, 100)
    )

    # Render menu options
    menu_font = pygame.font.Font(None, 50)
    for index, option in enumerate(self.menu_options):
        color = (0, 255, 0) if index == self.selected_option else (255, 255, 255)
        text = menu_font.render(option, True, color)
        self.display_surface.blit(
            text,
            (WINDOW_WIDTH // 2 - text.get_width() // 2, 250 + index * 60)
        )

    # Navigation hint
    hint_font = pygame.font.Font(None, 30)
    hint_text = hint_font.render("Use UP/DOWN keys to navigate and ENTER to select", True, (200, 200, 200))
    self.display_surface.blit(
        hint_text,
        (WINDOW_WIDTH // 2 - hint_text.get_width() // 2, WINDOW_HEIGHT - 100)
    )

    # Handle menu navigation
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_DOWN:
                self.selected_option = (self.selected_option + 1) % len(self.menu_options)
            elif event.key == pygame.K_UP:
                self.selected_option = (self.selected_option - 1) % len(self.menu_options)
            elif event.key == pygame.K_RETURN:
                if self.selected_option == 0:  # Play Now
                    self.in_menu = False
                elif self.selected_option == 1:  # Settings
                    print("Settings selected!")  # Add your settings logic here
                elif self.selected_option == 2:  # Credits
                    print("Credits selected!")  # Add your credits logic here
