from settings import * 
from level import Level
from pytmx.util_pygame import load_pygame
from os.path import join
from support import *
from data import Data
from debug import debug
from ui import UI
from overworld import Overworld

class Game:
  def __init__(self):
    pygame.init()
    self.display_surface = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
    pygame.display.set_caption('JVPirates')
    self.clock = pygame.time.Clock()
    self.import_assets()
    
    # menu 
    self.menu_options = ["Play Now", "Settings", "Credits"]
    self.selected_option = 0
    self.in_menu = True  # Start with the menu

    self.ui = UI(self.font, self.ui_frames)
    self.data = Data(self.ui)
    self.tmx_maps = {
      0: load_pygame(join('data', 'levels', '0.tmx')),
      1: load_pygame(join('data', 'levels', '1.tmx')),
      2: load_pygame(join('data', 'levels', '2.tmx')),
      3: load_pygame(join('data', 'levels', '3.tmx')),
      4: load_pygame(join('data', 'levels', '4.tmx')),
      5: load_pygame(join('data', 'levels', '5.tmx')),
      }
    self.tmx_overworld = load_pygame(join('data', 'overworld', 'overworld.tmx'))
    self.current_stage = Level(self.tmx_maps[self.data.current_level], self.level_frames, self.audio_files, self.data, self.switch_stage)
    self.bg_music.play(-1)
  
  def switch_stage(self, target, unlock = 0):
    if target == 'level':
      self.current_stage = Level(self.tmx_maps[self.data.current_level], self.level_frames, self.audio_files, self.data, self.switch_stage)
    else: # overworld
      if unlock > 0:
        self.data.unlocked_level = unlock
      else:
        self.data.health -= 1
      self.current_stage = Overworld(self.tmx_overworld, self.data, self.overworld_frames, self.switch_stage)



  def run_menu(self):
      """Handles menu logic and rendering."""
      # Render TMX map
      tmx_path='data/overworld/overworld.tmx'
      tmx_data = load_pygame(tmx_path)
      tile_size = tmx_data.tilewidth

      for layer in tmx_data.visible_layers:
          if hasattr(layer, "tiles"):
              for x, y, image in layer.tiles():
                  pos = (x * tile_size, y * tile_size)
                  self.display_surface.blit(image, pos)
      # Title text
      title_font = pygame.font.Font(None, 100)
      title_text = title_font.render("GAME MENU", True, (255, 255, 255))
      self.display_surface.blit(title_text, (WINDOW_WIDTH // 2 - title_text.get_width() // 2, 50))

      # Render menu options
      menu_font = pygame.font.Font(None, 50)
      for index, option in enumerate(self.menu_options):
          color = (0, 255, 0) if index == self.selected_option else (255, 255, 255)
          text = menu_font.render(option, True, color)
          self.display_surface.blit(text, (WINDOW_WIDTH // 2 - text.get_width() // 2, 200 + index * 60))

      # Navigation hint
      hint_font = pygame.font.Font(None, 30)
      hint_text = hint_font.render("Use UP/DOWN keys to navigate and ENTER to select", True, (200, 200, 200))
      self.display_surface.blit(hint_text, (WINDOW_WIDTH // 2 - hint_text.get_width() // 2, WINDOW_HEIGHT - 50))

      # Handle menu navigation
      for event in pygame.event.get():
          if event.type == pygame.QUIT:
              pygame.quit()
              sys.exit()
          elif event.type == pygame.KEYDOWN:
              if event.key == pygame.K_DOWN:
                  self.selected_option = (self.selected_option + 1) % len(self.menu_options)
              elif event.key == pygame.K_UP:
                  self.selected_option = (self.selected_option - 1) % len(self.menu_options)
              elif event.key == pygame.K_RETURN:
                  if self.selected_option == 0:  # Start game
                      self.in_menu = False
                  elif self.selected_option == 1:  # Settings
                      print("Settings selected")
                  elif self.selected_option == 2:  # Quit
                      pygame.quit()
                      sys.exit()




  def import_assets(self):
    self.level_frames = {
      'flag': import_folder('graphics', 'level', 'flag'),
      'saw': import_folder('graphics', 'enemies', 'saw', 'animation'),
      'floor_spike': import_folder('graphics', 'enemies', 'floor_spikes'),
      'palms': import_sub_folders('graphics', 'level', 'palms'),
      'candle': import_folder('graphics', 'level', 'candle'),
      'window': import_folder('graphics', 'level', 'window'),
      'big_chain': import_folder('graphics', 'level', 'big_chains'),
      'small_chain': import_folder('graphics', 'level', 'small_chains'),
      'candle_light': import_folder('graphics', 'level', 'candle light'),
      'player': import_sub_folders('graphics', 'player'),
      'saw': import_folder('graphics', 'enemies', 'saw', 'animation'),
      'saw_chain': import_image('graphics', 'enemies', 'saw','saw_chain'),
      'helicopter': import_folder('graphics', 'level', 'helicopter'),
      'boat': import_folder('graphics', 'objects', 'boat'),
      'spike': import_image('graphics', 'enemies', 'spike_ball', 'Spiked Ball'),
      'spike_chain': import_image('graphics', 'enemies', 'spike_ball', 'spiked_chain'),
      'tooth': import_folder('graphics', 'enemies', 'tooth', 'run'),
      'shell': import_sub_folders('graphics', 'enemies', 'shell'),
      'perl': import_image('graphics', 'enemies', 'bullets', 'pearl'),
      'items': import_sub_folders('graphics', 'items'),
      'particle': import_folder('graphics', 'effects', 'particle'),
      'water_top': import_folder('graphics', 'level', 'water', 'top'),
			'water_body': import_image('graphics', 'level', 'water', 'body'),
      'bg_tiles': import_folder_dict('graphics', 'level', 'bg', 'tiles'),
			'cloud_small': import_folder('graphics','level', 'clouds', 'small'),
			'cloud_large': import_image('graphics','level', 'clouds', 'large_cloud')
    } 
    self.font = pygame.font.Font(join('graphics', 'ui', 'runescape_uf.ttf'), 40)
    self.ui_frames = {
      'heart': import_folder('graphics', 'ui', 'heart'), 
			'coin':import_image('graphics', 'ui', 'coin') 
    }
    self.overworld_frames = {
      'palms': import_folder('graphics', 'overworld', 'palm'),
			'water': import_folder('graphics', 'overworld', 'water'),
			'path': import_folder_dict('graphics', 'overworld', 'path'),
			'icon': import_sub_folders('graphics', 'overworld', 'icon')
    }
    
    self.audio_files = {
      'coin': pygame.mixer.Sound(join('audio', 'coin.wav')),
			'attack': pygame.mixer.Sound(join('audio', 'attack.wav')),
			'jump': pygame.mixer.Sound(join('audio', 'jump.wav')), 
			'damage': pygame.mixer.Sound(join('audio', 'damage.wav')),
			'perl': pygame.mixer.Sound(join('audio', 'pearl.wav'))
    }
    self.bg_music = pygame.mixer.Sound(join('audio', 'starlight_city.mp3'))
    self.bg_music.set_volume(0.4)
   
  def check_game_over(self):
     if self.data.health <= 0:
       pygame.quit()
       sys.exit()
    
  def run(self):
      while True: 
          dt = self.clock.tick(60) / 1000  # Set to 60 FPS

          if self.in_menu: 
              self.run_menu()  # Call the menu when active
          else:
              self.current_stage.run(dt)  # Existing game logic
              self.ui.update(dt)         # UI updates

          pygame.display.update()


if __name__ == '__main__':
	game = Game()
	game.run()